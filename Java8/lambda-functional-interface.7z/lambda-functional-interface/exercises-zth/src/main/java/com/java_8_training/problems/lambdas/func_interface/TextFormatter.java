package com.java_8_training.problems.lambdas.func_interface;


public interface TextFormatter {
    String format(String s);

}
